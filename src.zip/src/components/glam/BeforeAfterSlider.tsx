"use client";

import { useCallback, useRef, useState } from "react";
import { ChevronsLeftRight, ZoomIn } from "lucide-react";

interface BeforeAfterSliderProps {
  before: string;
  after: string;
  alt?: string;
  /** v44.1: нажатие на фото без перетаскивания — открыть лупу деталей */
  onTapPhoto?: () => void;
}

export function BeforeAfterSlider({
  before,
  after,
  alt = "Макияж",
  onTapPhoto,
}: BeforeAfterSliderProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const draggingRef = useRef(false);
  // Точка первого касания: отличаем тап (открыть лупу) от перетаскивания шторки
  const downRef = useRef<{ x: number; y: number } | null>(null);
  const [pos, setPos] = useState(50);

  const update = useCallback((clientX: number) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return;
    const p = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.min(100, Math.max(0, p)));
  }, []);

  return (
    <div className="mx-auto w-full max-w-md">
      <div className="rounded-[22px] bg-[#064A28] p-1.5 shadow-[0_14px_44px_rgba(3,40,22,0.5)] ring-1 ring-[#F6B93B]/30">
        <div
          ref={containerRef}
          role="slider"
          tabIndex={0}
          aria-label="Сравнение до и после макияжа"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(pos)}
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - 5));
            if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + 5));
          }}
          onPointerDown={(e) => {
            draggingRef.current = true;
            downRef.current = { x: e.clientX, y: e.clientY };
            containerRef.current?.setPointerCapture(e.pointerId);
          }}
          onPointerMove={(e) => {
            if (draggingRef.current) update(e.clientX);
          }}
          onPointerUp={(e) => {
            // Тап без перетаскивания — открываем лупу деталей. Перетаскивание
            // шторки осталось как было: тянешь — шторка едет, тапнул — лупа.
            if (downRef.current) {
              const moved = Math.hypot(
                e.clientX - downRef.current.x,
                e.clientY - downRef.current.y,
              );
              if (moved < 8) onTapPhoto?.();
            }
            draggingRef.current = false;
            downRef.current = null;
          }}
          onPointerCancel={() => {
            draggingRef.current = false;
            downRef.current = null;
          }}
          className="relative w-full cursor-ew-resize touch-none select-none overflow-hidden rounded-[18px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F6B93B]"
        >
          {/* После (полностью) */}
          <img src={after} alt={alt} className="block w-full" draggable={false} />

          {/* До (обрезается шторкой) */}
          <img
            src={before}
            alt="До макияжа"
            draggable={false}
            className="absolute inset-0 h-full w-full object-cover"
            style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
          />

          {/* Подписи */}
          <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-[#04281A]/85 px-2.5 py-0.5 text-[11px] font-semibold tracking-widest text-[#F8F1E1] backdrop-blur-sm">
            ДО
          </span>
          <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-gradient-to-r from-[#D4A437] to-[#F6B93B] px-2.5 py-0.5 text-[11px] font-semibold tracking-widest text-[#043E21] shadow-md">
            ПОСЛЕ
          </span>

          {/* v44.1: значок-подсказка — фото открывается в лупе по нажатию */}
          <span className="pointer-events-none absolute bottom-3 right-3 flex items-center gap-1 rounded-full bg-[#04281A]/85 px-2.5 py-1 text-[11px] font-medium text-[#F8F1E1] backdrop-blur-sm">
            <ZoomIn className="h-3.5 w-3.5" aria-hidden />
            Лупа
          </span>

          {/* Шторка */}
          <div
            className="pointer-events-none absolute inset-y-0"
            style={{ left: `calc(${pos}% - 1px)` }}
          >
            <div className="h-full w-0.5 bg-white/95 shadow-[0_0_12px_rgba(4,40,26,0.6)]" />
            <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2">
              <span
                aria-hidden
                className="handle-pulse absolute inset-0 rounded-full"
              />
              <div className="relative rounded-full border border-[#F6B93B]/60 bg-white p-1.5 text-[#A67C1B] shadow-lg transition-transform">
                <ChevronsLeftRight className="h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <p className="mt-2 text-center text-sm text-muted-foreground">
        Тяните шторку, чтобы сравнить. Нажмите на фото — откроется лупа.
      </p>
    </div>
  );
}
